const RateAppointmentStyle = {
  rateAppointmentheader: {
    color: "white",
    fontSize: "20px",
    padding: "11px",
    height: "70px",
    backgroundColor: "purple",
    display: "flex",
    justifyContent: "left",
    alignItems: "center",
    width: "100%",
  },
  commentsTextField: {
    marginBottom: "30px",
    marginLeft: "10px",
    marginTop: "20px",
  },
  rateStarSetting: {
    marginLeft: "10px",
  },
  rateAppointmentButton: {
    marginTop: "30px",
    marginLeft: "10px",
    marginBottom: "20px",
  },

  rateAppointmentAlert: {
    width: "50%",
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    margin: "auto",
    marginBottom: "20px",
  },
};

export default RateAppointmentStyle;
