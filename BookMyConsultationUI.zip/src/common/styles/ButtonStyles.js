const ButtonStyles = {
  bookAppointmentButton: {
    width: "40%",
    margin: "10px",
    color: "white",
    backgroundColor: "#1565c0",
  },
  viewDoctorDetailsButton: {
    width: "40%",
    margin: "10px",
    color: "white",
    backgroundColor: "green",
  },
};

export default ButtonStyles;
